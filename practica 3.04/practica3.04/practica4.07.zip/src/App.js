import React from 'react';
import Euromillon from './Componentes/Ejercicio2/Ejercicio2';
import './App.css';

import NumeroAleatorio from './Componentes/Ejercicio1/Ejercicio1';


function App() {
  return (
    <div className="App">
    {/*<NumeroAleatorio/>*/}
    {<Euromillon/>}
    </div>
  );
}

export default App;
