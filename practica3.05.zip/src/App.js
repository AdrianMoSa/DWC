import './App.css';
import React from "react";
import { Calculadora } from './Calculadora/Calculadora';

function App() {
  return (
    <React.Fragment>
      <Calculadora/>
    </React.Fragment>
  );
}

export default App;
