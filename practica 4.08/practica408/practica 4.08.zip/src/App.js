
import React from "react";
import { Lista_compra } from './lista_compra/Lista_compra';
import './lista_compra/Lista_compra.css'

function App() {
  return (
    <React.Fragment>
      <Lista_compra />
    </React.Fragment>
  );
}

export default App;
