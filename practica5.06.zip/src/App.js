import React from "react";
import Ejercicio1 from "./Ejercicio1/Ejercicio1";
import Ejercicio2 from "./Ejercicio2/Ejercicio2";


function App() {
  return (
    <React.Fragment>
      <Ejercicio1></Ejercicio1>
      <Ejercicio2></Ejercicio2>
    </React.Fragment>
  );
}

export default App;
