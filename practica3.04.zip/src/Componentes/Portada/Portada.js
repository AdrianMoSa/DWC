import React from 'react'

export const Portada = (props) => {
  return (
    <img src={props.cartelera} alt="vacio"></img>
  )
}
