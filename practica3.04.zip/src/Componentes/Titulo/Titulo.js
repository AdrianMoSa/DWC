import React from 'react'

export const Titulo = (props) => {
  return (
    <h1>{props.nombre}</h1>
  )
}
