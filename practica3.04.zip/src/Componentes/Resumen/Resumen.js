import React from 'react'

export const Resumen = (props) => {
  return (
    <div>{props.resumen}</div>
  )
}
