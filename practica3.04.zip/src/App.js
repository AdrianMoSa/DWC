
import './App.css';
import { Contenedor } from './Componentes/Contenedor/Contenedor';

function App() {
  return (
    <div className="App">
     <Contenedor></Contenedor>
    </div>
  );
}

export default App;
