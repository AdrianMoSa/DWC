"use strict";

//Juan Carlos no me ha dado tiempo a hacerlo, ya que tenía muchas prácticas para entregar y tenemos examen mañana. Lo siento :( .